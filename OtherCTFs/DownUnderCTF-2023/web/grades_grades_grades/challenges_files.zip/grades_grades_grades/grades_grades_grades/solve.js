


var jwt = require('jsonwebtoken');


header = '{"alg":"HS256","typ":"JWT"}'
payload = '{"iat":1422779638, "is_auth":"True", "is_teacher_role":"True"}
key = 'secretkey'
unsignedToken = encodeBase64(header) + '.' + encodeBase64(payload)
signature = HMAC-SHA256(key, unsignedToken)
token = encodeBase64(header) + '.' + encodeBase64(payload) + '.' + encodeBase64(signature)
